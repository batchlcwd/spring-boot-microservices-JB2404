package com.substring.foodie.entity.enums;

public enum PaymentMode {

    ONLINE, CASH_ON_DELIVERY, CHEQUE,
}
