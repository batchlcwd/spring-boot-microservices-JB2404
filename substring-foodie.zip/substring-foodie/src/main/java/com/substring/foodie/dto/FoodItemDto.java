package com.substring.foodie.dto;

public class FoodItemDto {
}
