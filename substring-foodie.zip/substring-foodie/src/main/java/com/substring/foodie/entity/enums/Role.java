package com.substring.foodie.entity.enums;

public enum Role {
    ADMIN, USER, DELIVERY_BOY,RESTAURANT
}
