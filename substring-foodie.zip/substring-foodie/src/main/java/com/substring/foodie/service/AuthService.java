package com.substring.foodie.service;

import com.substring.foodie.dto.UserDto;

public interface AuthService {

    UserDto registerUser(UserDto userDto);

}
