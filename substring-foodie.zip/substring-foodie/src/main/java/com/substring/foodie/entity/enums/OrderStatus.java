package com.substring.foodie.entity.enums;

public enum OrderStatus {
    PLACED,ACCEPTED,REJECTED,PREPARING,PICKED_UP,DELIVERED,CANCELLED
}
