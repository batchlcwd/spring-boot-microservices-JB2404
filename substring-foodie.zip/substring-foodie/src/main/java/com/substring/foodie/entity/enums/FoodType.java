package com.substring.foodie.entity.enums;

public enum FoodType {

    NONVEG, VEG

}
