package com.substring.foodie.entity.enums;

public enum PaymentStatus {
    NOT_PAID, PAID,REFUNDED
}
